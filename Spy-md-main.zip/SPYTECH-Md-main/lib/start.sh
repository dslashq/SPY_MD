while true
do
echo "Starting SPY-Md!"
node .
done